
python3 make-package --head=PKG-README dist
