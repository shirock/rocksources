#!/bin/sh
systemctl stop php7.4-fpm.service
systemctl disable php7.4-fpm.service
